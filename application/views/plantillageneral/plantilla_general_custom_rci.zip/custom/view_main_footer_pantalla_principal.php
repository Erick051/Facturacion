  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      <a href="#" onclick='$("#chat").toggle();'>Contacte a soporte</a>
    </div>

    <!-- Default to the left -->
    <strong>Copyright &copy; 2017 <a href="#">STO Consulting DCC</a>.</strong>
    
  </footer>